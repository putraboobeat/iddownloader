import { Detector } from './detector.js';
import { APIClient } from './api.js';
import { Config, BASE_URL } from './config.js';
import { JobManager } from './jobs.js';

// === Persistent Submission Coordinator ===
// Melindungi pengiriman tugas dan retry lintas-popup serta bertahan saat worker restart
export class SubmissionCoordinator {
    static async acquire(key) {
        if (!key) return false;
        const now = Date.now();
        const data = await chrome.storage.local.get('omni_in_flight_submissions');
        const submissions = data.omni_in_flight_submissions || {};

        // Bersihkan entri kedaluwarsa (> 60 detik)
        for (const [k, v] of Object.entries(submissions)) {
            if (now - (v.startedAt || 0) > 60000) {
                delete submissions[k];
            }
        }

        if (submissions[key] && submissions[key].status === 'submitting') {
            return false;
        }

        submissions[key] = { startedAt: now, status: 'submitting' };
        await chrome.storage.local.set({ omni_in_flight_submissions: submissions });
        return true;
    }

    static async release(key) {
        if (!key) return;
        const data = await chrome.storage.local.get('omni_in_flight_submissions');
        const submissions = data.omni_in_flight_submissions || {};
        delete submissions[key];
        await chrome.storage.local.set({ omni_in_flight_submissions: submissions });
    }

    static async markUncertain(key, reason = 'TIMEOUT') {
        if (!key) return;
        const data = await chrome.storage.local.get('omni_in_flight_submissions');
        const submissions = data.omni_in_flight_submissions || {};
        if (submissions[key]) {
            submissions[key].status = 'uncertain';
            submissions[key].reason = reason;
            submissions[key].uncertainAt = Date.now();
            await chrome.storage.local.set({ omni_in_flight_submissions: submissions });
        }
    }
}

/**
 * Penyamaran menyeluruh untuk laporan diagnostik:
 * - Token sesi (omni[a-f0-9]+ atau session=xxx)
 * - Cookie / Header autentikasi (Authorization, Cookie, Set-Cookie)
 * - Query URL bertanda tangan (sig, signature, token, auth, key, secret, expires, dll)
 * - URL sensitif yang memuat kredensial atau token dalam pesan error
 */
export function maskSensitive(text) {
    if (!text || typeof text !== 'string') return text || '';
    let result = text;

    // 1. Token sesi sintetis maupun riil
    result = result.replace(/omni[a-f0-9]{8,}/gi, (match) => match.slice(0, 4) + '***[REDACTED_SESSION]');
    result = result.replace(/([?&]session=)[^&\s"'`]+/gi, '$1[REDACTED_TOKEN]');

    // 2. Query URL bertanda tangan & parameter otentikasi
    result = result.replace(/([?&](?:sig|signature|token|auth|key|secret|expires|Signature|Expires|AWSAccessKeyId|SignatureValue)=)[^&\s"'`]+/gi, '$1[REDACTED_PARAM]');

    // 3. Header autentikasi dan Cookie
    result = result.replace(/((?:Authorization|Cookie|Set-Cookie):\s*)[^\r\n]+/gi, '$1[REDACTED_HEADER]');
    result = result.replace(/((?:bearer|basic)\s+)[a-zA-Z0-9_\-\.]+/gi, '$1[REDACTED_AUTH]');

    // 4. Kredensial URL (https://user:password@domain)
    result = result.replace(/(https?:\/\/)([^:\s\/]+):([^@\s\/]+)@/gi, '$1[REDACTED_USER]:[REDACTED_PASS]@');

    return result;
}

// === Migration, Setup & Worker Startup ===
chrome.runtime.onInstalled.addListener(async () => {
    await chrome.storage.local.set({ app: BASE_URL });
    await Config.ensureSessionToken();

    try {
        chrome.contextMenus.create({
            id: 'omni-download-link',
            title: '\uD83D\uDE80 OmniFetch: Unduh URL',
            contexts: ['link', 'video', 'page']
        });
    } catch (e) {}

    // Buat alarm periodik untuk pemulihan dan monitoring latar belakang
    chrome.alarms.create('omni-job-poller', { periodInMinutes: 1 });
});

chrome.runtime.onStartup.addListener(async () => {
    // Pastikan alarm selalu terpasang setelah browser restart
    chrome.alarms.create('omni-job-poller', { periodInMinutes: 1 });
    
    // Bangkitkan pemantauan pekerjaan aktif dan rekonsiliasi unduhan lokal
    JobManager.startPollingLoop();
});

// Alarm Listener (Service Worker Lifecycle Resilience)
chrome.alarms.onAlarm.addListener(alarm => {
    if (alarm.name === 'omni-job-poller') {
        JobManager.startPollingLoop();
    } else if (alarm.name === 'omni-cookie-sync') {
        Config.getAppInfo().then(info => {
            if (info.cookieSync && info.cookieDomains?.length > 0) {
                APIClient.syncCookies(info.cookieDomains).catch(() => {});
            }
        });
    }
});

// Downloads API Listener (Pantau keberhasilan simpan ke komputer)
if (chrome.downloads && chrome.downloads.onChanged) {
    chrome.downloads.onChanged.addListener(delta => {
        JobManager.handleDownloadDelta(delta);
    });
}

// === Network Listener untuk Sniffer Media ===
chrome.webRequest.onResponseStarted.addListener(d => {
    if (d.tabId < 0 || ![200, 206].includes(d.statusCode)) return;
    const mime = (d.responseHeaders || []).find(h => h.name.toLowerCase() === 'content-type')?.value || '';
    
    if (mime.includes('image/') || mime.includes('text/html') || mime.includes('javascript') || mime.includes('css')) return;
    
    Detector.addCandidate(d.tabId, d.url, mime.toLowerCase(), d.initiator).catch(() => {});
}, { urls: ['*://*/*'] }, ['responseHeaders']);

// === Navigation Cleanup ===
chrome.webRequest.onBeforeRequest.addListener(d => {
    if (d.tabId < 0 || d.type !== 'main_frame') return;
    Detector.clear(d.tabId).catch(() => {});
}, { urls: ['http://*/*', 'https://*/*'], types: ['main_frame'] });

chrome.tabs.onRemoved.addListener(id => {
    Detector.clear(id).catch(() => {});
});

// === Messaging: Pemisahan Operasi Jaringan dari Queue Lokal ===
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (sender.id !== chrome.runtime.id) return;

    if (message.type === 'SEND_JOB') {
        (async () => {
            const targetUrl = message.payload?.urls || message.payload?.url || '';
            const submissionKey = `${targetUrl}::${message.payload?.media_type || ''}`;

            const acquired = await SubmissionCoordinator.acquire(submissionKey);
            if (!acquired) {
                sendResponse({ ok: false, error: 'Pekerjaan untuk URL ini sedang dalam proses pengiriman.' });
                return;
            }

            try {
                const sessionToken = await Config.ensureSessionToken();
                const res = await APIClient.sendJob(message.payload, sessionToken);
                if (res && res.job_id) {
                    await JobManager.addJob(res.job_id, message.payload, message.title || 'Media', sessionToken);
                }
                sendResponse({ ok: true, data: res });
            } catch (e) {
                if (e.code === 'TIMEOUT') {
                    await SubmissionCoordinator.markUncertain(submissionKey, 'TIMEOUT');
                    sendResponse({ 
                        ok: false, 
                        error: 'Waktu koneksi habis (Timeout). Server mungkin sudah menerima pekerjaan. Periksa status beberapa saat lagi sebelum mengirim ulang.',
                        code: 'TIMEOUT'
                    });
                } else {
                    sendResponse({ ok: false, error: e.message, code: e.code || 'UNKNOWN_ERROR' });
                }
            } finally {
                await SubmissionCoordinator.release(submissionKey);
            }
        })();
        return true;
    }

    if (message.type === 'RETRY_JOB') {
        (async () => {
            const retryKey = `retry::${message.jobId}`;
            const acquired = await SubmissionCoordinator.acquire(retryKey);
            if (!acquired) {
                sendResponse({ ok: false, error: 'Proses pengulangan untuk tugas ini sedang berjalan.' });
                return;
            }
            try {
                const res = await JobManager.retryJob(message.jobId);
                sendResponse(res);
            } catch (e) {
                sendResponse({ ok: false, error: e.message });
            } finally {
                await SubmissionCoordinator.release(retryKey);
            }
        })();
        return true;
    }

    if (message.type === 'INSPECT_URL') {
        (async () => {
            try {
                const sessionToken = await Config.ensureSessionToken();
                const res = await APIClient.inspectUrl(message.url, sessionToken);
                sendResponse(res);
            } catch (e) {
                sendResponse({ ok: false, error: e.message, code: e.code || 'INSPECT_FAILED' });
            }
        })();
        return true;
    }

    if (message.type === 'GET_JOB_STATUS') {
        (async () => {
            try {
                const { jobs } = await JobManager.getJobs();
                const localJob = jobs[message.jobId];
                if (localJob) {
                    sendResponse({ ok: true, job: localJob });
                } else {
                    const sessionToken = await Config.ensureSessionToken();
                    const remoteData = await APIClient.getJobStatus(message.jobId, sessionToken);
                    sendResponse({ ok: true, job: remoteData });
                }
            } catch (e) {
                sendResponse({ ok: false, error: e.message });
            }
        })();
        return true;
    }

    if (message.type === 'GET_ALL_JOBS') {
        JobManager.getJobs().then(data => sendResponse(data));
        return true;
    }

    if (message.type === 'STOP_JOB') {
        (async () => {
            try {
                const result = await JobManager.stopJob(message.jobId);
                sendResponse(result);
            } catch (e) {
                sendResponse({ ok: false, error: e.message });
            }
        })();
        return true;
    }

    if (message.type === 'GET_DIAGNOSTIC') {
        (async () => {
            try {
                const { jobs } = await JobManager.getJobs();
                const localJob = jobs[message.jobId];
                const sessionToken = localJob?.sessionToken || (await Config.ensureSessionToken());

                let remoteReport = '';
                try {
                    const diag = await APIClient.getDiagnostic(message.jobId, sessionToken);
                    remoteReport = diag?.report || '';
                } catch (rErr) {
                    remoteReport = `[Gagal mengambil log server: ${rErr.message}]`;
                }

                // Susun laporan diagnostik gabungan lengkap dengan status lokal
                const maskedSession = sessionToken ? sessionToken.slice(0, 6) + '***' : 'None';
                const filesSummary = localJob?.files?.map(f => 
                    `  - ${f.cleanName || f.name} [Status: ${f.status}, ID: ${f.downloadId || 'N/A'}, Size: ${f.size || 'N/A'}${f.error ? ', Error: ' + f.error : ''}]`
                ).join('\n') || '  (Belum ada file)';

                const combinedReport = `=== OmniFetch Comprehensive Diagnostic ===
Waktu Laporan: ${new Date().toISOString()}
Job ID: ${message.jobId}
Sesi Terikat: ${maskedSession}
Status Lokal: ${localJob?.status || 'N/A'}
Tahap: ${localJob?.stageLabel || 'N/A'}
Persentase: ${localJob?.percent || 0}%
Error Terakhir: ${localJob?.error || localJob?.lastPollError || 'None'}
Terakhir Diperbarui: ${localJob?.updatedAt ? new Date(localJob.updatedAt).toLocaleTimeString() : 'N/A'}

-- File Komputer Lokal --
${filesSummary}

-- Laporan Server (Disamarkan) --
${remoteReport}`;

                const sanitizedReport = maskSensitive(combinedReport);
                sendResponse({ ok: true, report: sanitizedReport });
            } catch (e) {
                sendResponse({ ok: false, error: e.message });
            }
        })();
        return true;
    }
    
    if (message.type === 'CHECK_SESSION') {
        APIClient.checkSession(message.token).then(res => sendResponse(res));
        return true;
    }

    if (message.type === 'GET_CANDIDATES') {
        const tabId = sender.tab ? sender.tab.id : message.tabId;
        if (!tabId) {
            sendResponse({ error: 'No tab context' });
            return;
        }
        Detector.getCandidates(tabId).then(items => sendResponse({ items }));
        return true;
    }
    
    if (message.type === 'ADD_CANDIDATES') {
        const tabId = sender.tab ? sender.tab.id : message.tabId;
        if (!tabId || !message.items) return;
        (async () => {
            for (const item of message.items) {
                await Detector.addCandidate(tabId, item.url, '', '', item.sourceType);
            }
            sendResponse({ ok: true });
        })();
        return true;
    }
    
    if (message.type === 'CLEAR_CANDIDATES') {
        const tabId = sender.tab ? sender.tab.id : message.tabId;
        if (tabId) {
            Detector.clear(tabId).then(() => sendResponse({ ok: true }));
            return true;
        }
    }
    
    if (message.type === 'SYNC_COOKIES') {
        (async () => {
            const domains = message.domains || ['.instagram.com', '.youtube.com', '.tiktok.com', '.twitter.com', '.x.com'];
            try {
                await APIClient.syncCookies(domains);
                sendResponse({ ok: true });
            } catch (e) {
                sendResponse({ ok: false, error: e.message });
            }
        })();
        return true;
    }
});

// === Context Menu ===
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
    const sessionToken = await Config.ensureSessionToken();
    if (!sessionToken) { 
        chrome.runtime.openOptionsPage(); 
        return; 
    }
    const url = info.linkUrl || info.srcUrl || info.pageUrl;
    if (!url) return;
    
    const submissionKey = `${url}::video`;
    const acquired = await SubmissionCoordinator.acquire(submissionKey);
    if (!acquired) return;

    try {
        const payload = { urls: url, mode: 'ytdlp', media_type: 'video', resolution: 'best' };
        const res = await APIClient.sendJob(payload, sessionToken);
        if (res && res.job_id) {
            await JobManager.addJob(res.job_id, payload, tab?.title || 'Unduhan Cepat', sessionToken);
        }
    } catch(e) {
        console.error("Context menu download failed", e.message);
    } finally {
        await SubmissionCoordinator.release(submissionKey);
    }
});
