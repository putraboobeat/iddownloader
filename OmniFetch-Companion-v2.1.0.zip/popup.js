import { BASE_URL, Config } from './background/config.js';
import { Detector } from './background/detector.js';

const $ = id => document.getElementById(id);
let currentTab = null;
let detectedItems = [];
let selectedMediaType = 'video'; // 'video' | 'audio' | 'subtitle'
let currentActiveJobId = null;
let lastKnownJob = null;
let isSubmitting = false;
let userExplicitNoSub = false;

const SOCIAL_DOMAINS = [
    'youtube.com', 'youtu.be', 'instagram.com', 'tiktok.com',
    'twitter.com', 'x.com', 'facebook.com', 'fb.watch', 'reddit.com'
];

function sanitize(str) {
    return (str || '').replace(/[\\/:*?"<>|\r\n\t]/g, '_').trim();
}

function showStatus(type, message) {
    const el = $('action-status');
    if (!el) return;
    if (!type || !message) {
        el.style.display = 'none';
        el.className = 'action-status';
        el.textContent = '';
        return;
    }
    el.className = `action-status ${type}`;
    el.textContent = message;
    el.style.display = 'block';
}

function showCookieStatus(type, message) {
    const el = $('cookie-status');
    if (!el) return;
    if (!type || !message) {
        el.style.display = 'none';
        el.className = 'action-status';
        el.textContent = '';
        return;
    }
    el.className = `action-status ${type}`;
    el.textContent = message;
    el.style.display = 'block';
}

// === TABS / PILLS SWITCHING ===
function setupTypePills() {
    const pills = [$('pill-video'), $('pill-audio'), $('pill-sub')];
    pills.forEach(pill => {
        if (!pill) return;
        pill.onclick = () => {
            pills.forEach(p => p.classList.remove('active'));
            pill.classList.add('active');
            selectedMediaType = pill.dataset.type;

            if (selectedMediaType === 'video') {
                $('video-options-group').style.display = 'block';
                $('audio-options-group').style.display = 'none';
                $('subtitle-options-group').style.display = 'block';
            } else if (selectedMediaType === 'audio') {
                $('video-options-group').style.display = 'none';
                $('audio-options-group').style.display = 'block';
                $('subtitle-options-group').style.display = 'none';
            } else if (selectedMediaType === 'subtitle') {
                $('video-options-group').style.display = 'none';
                $('audio-options-group').style.display = 'none';
                $('subtitle-options-group').style.display = 'block';
            }
        };
    });
}

// === REFRESH DETECTED MEDIA ===
async function refreshCandidates() {
    if (!currentTab || !currentTab.id) return;
    const previousSelectedMedia = $('media-select')?.value;
    const previousSelectedSub = $('subtitle-select')?.value;

    chrome.runtime.sendMessage({ type: 'GET_CANDIDATES', tabId: currentTab.id }, (res) => {
        if (chrome.runtime.lastError || !res || res.error) return;
        detectedItems = res.items || [];

        const mediaSelect = $('media-select');
        const subSelect = $('subtitle-select');
        mediaSelect.replaceChildren();
        subSelect.replaceChildren();

        const defaultMediaOpt = new Option('Pilih sumber video/stream…', '');
        mediaSelect.append(defaultMediaOpt);

        const defaultSubOpt = new Option('Tanpa subtitle tambahan', '__NONE__');
        subSelect.append(defaultSubOpt);

        const videoCandidates = detectedItems.filter(x => x.kind !== 'subtitle');
        const subCandidates = detectedItems.filter(x => x.kind === 'subtitle');

        for (const item of videoCandidates) {
            const label = `[${item.statusLabel || item.kind}] ${item.displayTitle || 'Media'}`;
            const opt = new Option(label, item.url);
            mediaSelect.append(opt);
        }

        for (const sub of subCandidates) {
            const label = `[${sub.statusLabel || 'Subtitle'}] ${sub.displayTitle || 'Sub'}`;
            const opt = new Option(label, sub.url);
            subSelect.append(opt);
        }

        // Pertahankan pilihan pengguna sebelumnya jika masih ada di daftar
        if (previousSelectedMedia && videoCandidates.some(x => x.url === previousSelectedMedia)) {
            mediaSelect.value = previousSelectedMedia;
        } else {
            // Pilih otomatis sumber terbaik
            const best = Detector.findBestMedia(videoCandidates);
            if (best) {
                mediaSelect.value = best.url;
                $('media-title').textContent = best.displayTitle || currentTab?.title || 'Media Video';
                $('media-platform-tag').textContent = best.statusLabel || 'Stream';
            }
        }

        if (userExplicitNoSub) {
            subSelect.value = '__NONE__';
        } else if (previousSelectedSub && subCandidates.some(x => x.url === previousSelectedSub)) {
            subSelect.value = previousSelectedSub;
        } else {
            // Cari subtitle yang berkorelasi dengan sumber video terpilih
            const chosenMedia = $('media-select')?.value || currentTab?.url || '';
            const bestSub = Detector.findDefaultSubtitle(subCandidates, chosenMedia);
            if (bestSub) {
                subSelect.value = bestSub.url;
            } else {
                subSelect.value = '__NONE__';
            }
        }
    });
}

// === METADATA INSPECTOR VIA API (Untuk YouTube, IG, TikTok, X, dll) ===
async function inspectPageMetadata(url) {
    if (!url) return;
    $('media-title').textContent = 'Menganalisis info media…';

    chrome.runtime.sendMessage({ type: 'INSPECT_URL', url: url }, (res) => {
        if (chrome.runtime.lastError || !res || !res.ok || !res.info) {
            // Fallback ke info tab
            $('media-title').textContent = currentTab?.title || 'Media Video';
            $('media-platform-tag').textContent = 'Halaman Web';
            return;
        }

        const info = res.info;
        if (info.title) $('media-title').textContent = info.title;
        if (info.thumbnail) $('media-thumb').src = info.thumbnail;

        if (info.duration) {
            $('media-duration-tag').style.display = 'inline-block';
            $('media-duration-tag').textContent = `⏱ ${info.duration}`;
        }

        $('media-platform-tag').textContent = info.is_instagram ? 'Instagram' : (info.uploader || 'Online Media');

        // Sesuaikan pilihan resolusi yang tersedia di server
        if (Array.isArray(info.formats) && info.formats.length > 0) {
            const qSelect = $('video-quality');
            qSelect.replaceChildren();
            qSelect.append(new Option('Kualitas Terbaik (Otomatis)', 'best'));
            for (const f of info.formats) {
                if (typeof f === 'number') {
                    qSelect.append(new Option(`${f}p HD`, String(f)));
                }
            }
        }
    });
}

// === JOB MONITOR UI UPDATE ===
function renderJobMonitor(job) {
    if (!job) {
        $('job-monitor-card').style.display = 'none';
        return;
    }

    lastKnownJob = job;
    currentActiveJobId = job.id;
    $('job-monitor-card').style.display = 'block';

    $('job-title-display').textContent = job.title || 'Unduhan Media';
    $('job-stage-display').textContent = job.stageLabel || 'Memproses…';

    const isLocalSaving = job.status === 'saving';
    const isCompleted = job.status === 'completed';
    const isFailed = job.status === 'failed' || job.downloadStatus === 'interrupted' || job.downloadStatus === 'failed';
    const isCancelled = job.status === 'cancelled';

    // Perhitungan persentase jujur
    if (isCompleted) {
        $('job-progress-fill').style.width = '100%';
        $('job-percent-text').textContent = '100%';
        $('job-speed-text').textContent = '';
        $('job-eta-text').textContent = '';
    } else if (isLocalSaving) {
        // Jangan klaim 100% jika masih menyimpan ke komputer
        const files = Array.isArray(job.files) ? job.files : [];
        const totalExpected = files.reduce((acc, f) => acc + (f.totalBytes || 0), 0);
        const totalReceived = files.reduce((acc, f) => acc + (f.bytesReceived || 0), 0);

        if (totalExpected > 0) {
            const localPct = Math.max(0, Math.min(99, Math.round((totalReceived / totalExpected) * 100)));
            $('job-progress-fill').style.width = `${localPct}%`;
            $('job-percent-text').textContent = `${localPct}% (Lokal)`;
            const mbRec = (totalReceived / (1024 * 1024)).toFixed(1);
            const mbTot = (totalExpected / (1024 * 1024)).toFixed(1);
            $('job-speed-text').textContent = `${mbRec}/${mbTot} MB`;
            $('job-eta-text').textContent = 'Menulis ke disk';
        } else {
            // Belum ada data byte dari Chrome: tampilkan indikator transfer tanpa persentase rekaan
            $('job-progress-fill').style.width = '99%';
            $('job-percent-text').textContent = 'Menyimpan…';
            $('job-speed-text').textContent = files.length > 0 ? `${files.length} file` : '';
            $('job-eta-text').textContent = '';
        }
    } else if (isFailed) {
        const pct = Math.max(0, Math.min(100, Math.round(job.percent || 0)));
        $('job-progress-fill').style.width = `${pct}%`;
        $('job-percent-text').textContent = `${pct}% (Gagal)`;
        $('job-speed-text').textContent = '';
        $('job-eta-text').textContent = '';
    } else {
        // Progres server
        const pct = Math.max(0, Math.min(99, Math.round(job.percent || 0)));
        $('job-progress-fill').style.width = `${pct}%`;
        $('job-percent-text').textContent = `${pct}%`;
        $('job-speed-text').textContent = job.speed ? `Kecepatan: ${job.speed}` : '';
        $('job-eta-text').textContent = job.eta ? `ETA: ${job.eta}` : '';
    }

    const badge = $('job-badge');
    badge.className = 'meta-tag';

    if (isCompleted) {
        badge.textContent = 'Selesai';
        badge.style.background = '#052e16';
        badge.style.color = '#86efac';
        $('btn-job-stop').style.display = 'none';
        $('btn-job-retry').style.display = 'none';
    } else if (isFailed) {
        badge.textContent = job.downloadStatus === 'interrupted' ? 'Terputus' : 'Gagal';
        badge.style.background = '#450a0a';
        badge.style.color = '#fca5a5';
        $('btn-job-stop').style.display = 'none';
        $('btn-job-retry').style.display = 'block';
    } else if (isCancelled) {
        badge.textContent = 'Dibatalkan';
        badge.style.background = '#27272a';
        badge.style.color = '#d4d4d8';
        $('btn-job-stop').style.display = 'none';
        $('btn-job-retry').style.display = 'block';
    } else if (isLocalSaving) {
        badge.textContent = 'Menyimpan';
        badge.style.background = '#1e1b4b';
        badge.style.color = '#a5b4fc';
        $('btn-job-stop').style.display = 'block';
        $('btn-job-retry').style.display = 'none';
    } else {
        badge.textContent = 'Berjalan';
        badge.style.background = '#3d0f19';
        badge.style.color = '#ff8fa3';
        $('btn-job-stop').style.display = 'block';
        $('btn-job-retry').style.display = 'none';
    }

    // Tampilkan daftar status per-file jika ada
    const filesDisplay = $('job-files-display');
    if (filesDisplay) {
        const files = Array.isArray(job.files) ? job.files : [];
        if (files.length > 0) {
            filesDisplay.style.display = 'block';
            filesDisplay.replaceChildren();
            for (const f of files) {
                const itemDiv = document.createElement('div');
                itemDiv.style.display = 'flex';
                itemDiv.style.justifyContent = 'space-between';
                itemDiv.style.padding = '2px 0';
                itemDiv.style.borderTop = '1px solid #220810';

                const nameSpan = document.createElement('span');
                nameSpan.style.overflow = 'hidden';
                nameSpan.style.textOverflow = 'ellipsis';
                nameSpan.style.whiteSpace = 'nowrap';
                nameSpan.style.maxWidth = '210px';
                nameSpan.textContent = f.cleanName || f.name;

                const statusSpan = document.createElement('span');
                if (f.status === 'completed') {
                    statusSpan.style.color = '#86efac';
                    statusSpan.textContent = '✔ Tersimpan';
                } else if (f.status === 'interrupted' || f.status === 'failed') {
                    statusSpan.style.color = '#fca5a5';
                    statusSpan.textContent = `✖ ${f.error || 'Gagal'}`;
                } else {
                    statusSpan.style.color = '#fde047';
                    statusSpan.textContent = '⏳ Mengunduh…';
                }

                itemDiv.append(nameSpan, statusSpan);
                filesDisplay.append(itemDiv);
            }
        } else {
            filesDisplay.style.display = 'none';
        }
    }
}

// === LOAD ACTIVE & RECENT JOBS ===
async function loadJobsState() {
    chrome.runtime.sendMessage({ type: 'GET_ALL_JOBS' }, (data) => {
        if (!data || !data.jobs) return;
        const jobs = Object.values(data.jobs).sort((a, b) => b.createdAt - a.createdAt);
        
        // Cari job yang sedang aktif terlebih dahulu
        const activeJob = jobs.find(j => ['queued', 'downloading', 'validating', 'saving'].includes(j.status)) || jobs[0];
        if (activeJob) {
            renderJobMonitor(activeJob);
        }

        // Render riwayat ke accordion
        const historyContainer = $('history-list');
        if (jobs.length === 0) {
            historyContainer.replaceChildren();
            const emptyNotice = document.createElement('div');
            emptyNotice.style.color = '#666';
            emptyNotice.style.fontSize = '10px';
            emptyNotice.textContent = 'Belum ada riwayat unduhan.';
            historyContainer.append(emptyNotice);
            return;
        }

        historyContainer.replaceChildren();
        for (const j of jobs.slice(0, 10)) {
            const row = document.createElement('div');
            row.style.padding = '6px 0';
            row.style.borderBottom = '1px solid #220810';
            row.style.display = 'flex';
            row.style.justifyContent = 'space-between';
            row.style.alignItems = 'center';

            const left = document.createElement('div');
            left.style.minWidth = '0';
            left.style.flex = '1';

            const jTitle = document.createElement('div');
            jTitle.style.fontWeight = '600';
            jTitle.style.fontSize = '11px';
            jTitle.style.color = '#fff';
            jTitle.style.overflow = 'hidden';
            jTitle.style.textOverflow = 'ellipsis';
            jTitle.style.whiteSpace = 'nowrap';
            jTitle.textContent = j.title || 'Media';

            const jSub = document.createElement('div');
            jSub.style.fontSize = '10px';
            jSub.style.color = '#888';
            jSub.textContent = `${new Date(j.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} • ${j.status}`;

            left.append(jTitle, jSub);

            const btnInspect = document.createElement('button');
            btnInspect.className = 'btn-sm';
            btnInspect.style.flex = 'none';
            btnInspect.style.padding = '3px 8px';
            btnInspect.style.fontSize = '10px';
            btnInspect.textContent = 'Lihat';
            btnInspect.onclick = () => renderJobMonitor(j);

            row.append(left, btnInspect);
            historyContainer.append(row);
        }
    });
}

// Listen to storage changes for live progress updates
chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.omni_jobs) {
        const jobs = changes.omni_jobs.newValue || {};
        if (currentActiveJobId && jobs[currentActiveJobId]) {
            renderJobMonitor(jobs[currentActiveJobId]);
        } else {
            const active = Object.values(jobs).find(j => ['queued', 'downloading', 'validating', 'saving'].includes(j.status));
            if (active) renderJobMonitor(active);
        }
    }
});

// === MAIN DOWNLOAD TRIGGER ===
async function triggerDownload() {
    if (isSubmitting) return;

    const btn = $('btn-download-main');
    btn.disabled = true;
    isSubmitting = true;
    showStatus(null);

    try {
        // Tentukan URL target
        let targetUrl = '';
        let referer = currentTab?.url || '';
        let mediaTitle = $('custom-name')?.value?.trim() || $('media-title')?.textContent || 'Unduhan Media';

        const selectedDropdownUrl = $('media-select')?.value;
        const selectedCandidate = detectedItems.find(x => x.url === selectedDropdownUrl);

        if (selectedDropdownUrl && selectedCandidate) {
            targetUrl = selectedCandidate.extractedMediaUrl || selectedCandidate.url;
            if (selectedCandidate.referer) referer = selectedCandidate.referer;
        } else if (currentTab && currentTab.url) {
            targetUrl = currentTab.url;
        }

        if (!targetUrl) {
            showStatus('error', 'Tidak ada sumber media atau URL yang terdeteksi.');
            btn.disabled = false;
            isSubmitting = false;
            return;
        }

        // Susun payload sesuai kemampuan backend
        const payload = {
            urls: targetUrl,
            referer: referer,
            media_type: selectedMediaType === 'audio' ? 'audio' : 'video'
        };

        if (mediaTitle) payload.name = sanitize(mediaTitle);

        if (selectedMediaType === 'video') {
            payload.resolution = $('video-quality')?.value || 'best';
            payload.video_format = 'mp4';

            const subUrl = $('subtitle-select')?.value;
            if (subUrl && subUrl !== '__NONE__') {
                payload.subtitle_url = subUrl;
                payload.embed_subs = $('embed-subs')?.checked ?? true;
            }
        } else if (selectedMediaType === 'audio') {
            payload.audio_format = $('audio-format')?.value || 'mp3';
            payload.audio_quality = '0';
        } else if (selectedMediaType === 'subtitle') {
            payload.mode = 'subtitle';
            const subUrl = $('subtitle-select')?.value;
            if (subUrl && subUrl !== '__NONE__') payload.urls = subUrl;
        }

        // Pilihan arsip ZIP atau file individual
        payload.prefer_zip = $('prefer-zip')?.checked ?? false;

        // Waktu potong jika ada
        const startTime = $('time-start')?.value?.trim();
        const endTime = $('time-end')?.value?.trim();
        if (startTime) payload.start_time = startTime;
        if (endTime) payload.end_time = endTime;

        // Preset cerdas
        const preset = $('preset-select')?.value;
        if (preset) payload.preset = preset;

        // Tentukan mode direct untuk streaming m3u8/mpd
        if (selectedCandidate && ['hls', 'dash'].includes(selectedCandidate.kind)) {
            payload.mode = 'direct';
        }

        btn.querySelector('span').textContent = 'Mengirim ke Server…';

        chrome.runtime.sendMessage({
            type: 'SEND_JOB',
            payload: payload,
            title: mediaTitle
        }, (res) => {
            btn.disabled = false;
            isSubmitting = false;
            btn.querySelector('span').textContent = 'Unduh Sekarang';

            if (chrome.runtime.lastError || !res || !res.ok) {
                const errMsg = res?.error || chrome.runtime.lastError?.message || 'Gagal mengirim tugas.';
                showStatus('error', `Gagal: ${errMsg}`);
            } else {
                showStatus('success', '✅ Pekerjaan berhasil dikirim ke server!');
                currentActiveJobId = res.data.job_id;
                loadJobsState();
            }
        });

    } catch (err) {
        btn.disabled = false;
        isSubmitting = false;
        btn.querySelector('span').textContent = 'Unduh Sekarang';
        showStatus('error', err.message);
    }
}

// === BUTTON EVENT HANDLERS ===
$('btn-download-main').onclick = triggerDownload;
$('btn-refresh').onclick = () => {
    refreshCandidates();
    loadJobsState();
};

if ($('subtitle-select')) {
    $('subtitle-select').onchange = (e) => {
        userExplicitNoSub = (e.target.value === '__NONE__' || e.target.value === '');
    };
}

$('btn-job-stop').onclick = () => {
    if (!currentActiveJobId) return;
    const btn = $('btn-job-stop');
    if (btn.disabled) return;
    btn.disabled = true;
    const origText = btn.textContent;
    btn.textContent = '⏳ Menghentikan…';
    showStatus('loading', 'Mengirim perintah penghentian ke server…');

    chrome.runtime.sendMessage({ type: 'STOP_JOB', jobId: currentActiveJobId }, (res) => {
        btn.disabled = false;
        btn.textContent = origText;
        if (chrome.runtime.lastError || !res || !res.ok) {
            const err = res?.error || chrome.runtime.lastError?.message || 'Gagal menghentikan tugas.';
            showStatus('error', `Gagal menghentikan: ${err}`);
        } else {
            showStatus('success', '⏹️ Permintaan stop terkonfirmasi.');
        }
        loadJobsState();
    });
};

$('btn-job-retry').onclick = () => {
    if (!currentActiveJobId) return;
    const btn = $('btn-job-retry');
    if (btn.disabled) return;
    btn.disabled = true;
    const origText = btn.textContent;
    btn.textContent = '⏳ Mencoba lagi…';
    showStatus('loading', 'Mengulang proses unduhan…');

    chrome.runtime.sendMessage({ type: 'RETRY_JOB', jobId: currentActiveJobId }, (res) => {
        btn.disabled = false;
        btn.textContent = origText;
        if (chrome.runtime.lastError || !res || !res.ok) {
            const err = res?.error || chrome.runtime.lastError?.message || 'Gagal mengulang unduhan.';
            showStatus('error', `Gagal coba lagi: ${err}`);
        } else {
            if (res.mode === 'local_files') {
                showStatus('success', '🔄 Mengunduh ulang file lokal yang terputus…');
            } else if (res.mode === 'new_server_job') {
                showStatus('success', '🔄 Tugas baru telah dikirim ke server!');
                if (res.newJobId) currentActiveJobId = res.newJobId;
            }
            loadJobsState();
        }
    });
};

$('btn-job-diag').onclick = () => {
    if (!currentActiveJobId) return;
    chrome.runtime.sendMessage({ type: 'GET_DIAGNOSTIC', jobId: currentActiveJobId }, async (res) => {
        if (res && res.report) {
            try {
                await navigator.clipboard.writeText(res.report);
                const btn = $('btn-job-diag');
                const orig = btn.textContent;
                btn.textContent = '✅ Disalin!';
                setTimeout(() => { btn.textContent = orig; }, 2000);
            } catch(e) {
                alert(res.report);
            }
        }
    });
};

$('btn-copy-media').onclick = async () => {
    const val = $('media-select')?.value;
    if (!val) return;
    try {
        await navigator.clipboard.writeText(val);
        const btn = $('btn-copy-media');
        const orig = btn.textContent;
        btn.textContent = '✅ Disalin!';
        setTimeout(() => { btn.textContent = orig; }, 2000);
    } catch(e) {}
};

$('btn-preview-media').onclick = () => {
    const val = $('media-select')?.value;
    const item = detectedItems.find(x => x.url === val);
    const modal = $('preview-modal');
    const content = $('preview-modal-content');
    const title = $('preview-modal-title');

    modal.style.display = 'block';
    title.textContent = item?.displayTitle || 'Cuplikan Playlist';
    content.textContent = item?.previewSnippet || val || 'Belum ada cuplikan respons teks yang tersimpan.';
};

$('btn-close-preview').onclick = () => {
    $('preview-modal').style.display = 'none';
};

$('btn-copy-preview').onclick = async () => {
    const text = $('preview-modal-content')?.textContent;
    if (text) {
        await navigator.clipboard.writeText(text);
        $('btn-copy-preview').textContent = '✅ Cuplikan Berhasil Disalin!';
        setTimeout(() => { $('btn-copy-preview').textContent = '📋 Salin Seluruh Cuplikan'; }, 2000);
    }
};

$('btn-deep-dom').onclick = async () => {
    const btn = $('btn-deep-dom');
    btn.textContent = 'Memindai DOM…';
    btn.disabled = true;

    try {
        const results = await chrome.scripting.executeScript({
            target: { tabId: currentTab.id },
            func: () => {
                const cands = [];
                document.querySelectorAll('video, audio, source, track').forEach(el => {
                    const src = el.currentSrc || el.src;
                    if (src && !src.startsWith('blob:') && !src.startsWith('data:')) {
                        let kind = el.tagName.toLowerCase();
                        if (kind === 'source') kind = el.closest('video') ? 'video' : 'audio';
                        if (kind === 'track') kind = 'subtitle';
                        cands.push({ url: src, kind: kind, time: Date.now(), sourceType: 'dom' });
                    }
                });
                return cands;
            }
        });

        if (results && results[0]?.result?.length > 0) {
            chrome.runtime.sendMessage({
                type: 'ADD_CANDIDATES',
                tabId: currentTab.id,
                items: results[0].result
            }, () => {
                refreshCandidates();
                showStatus('success', `✅ ${results[0].result.length} media baru ditemukan via DOM!`);
            });
        } else {
            showStatus('loading', 'Tidak ada elemen video/audio langsung di DOM. Putar pemutar web untuk menangkap streaming.');
        }
    } catch (e) {
        showStatus('error', 'Gagal analisis DOM: ' + e.message);
    } finally {
        btn.textContent = '🔍 Analisis Mendalam DOM Video';
        btn.disabled = false;
    }
};

$('btn-sync-cookies').onclick = () => {
    if (!currentTab || !currentTab.url) return;
    try {
        const domain = new URL(currentTab.url).hostname;
        showCookieStatus('loading', `Mengirim cookie untuk ${domain}…`);
        chrome.runtime.sendMessage({ type: 'SYNC_COOKIES', domains: [domain] }, (res) => {
            if (res && res.ok) {
                showCookieStatus('success', `✅ Cookie untuk ${domain} berhasil disinkronkan.`);
            } else {
                showCookieStatus('error', res?.error || 'Gagal sinkronisasi cookie.');
            }
        });
    } catch(e) {}
};

$('btn-open-options').onclick = () => chrome.runtime.openOptionsPage();
$('link-dashboard').onclick = (e) => {
    e.preventDefault();
    chrome.tabs.create({ url: BASE_URL });
};

// === INITIALIZATION ===
(async () => {
    setupTypePills();

    // Pastikan session token siap
    await Config.ensureSessionToken();

    // Query tab aktif
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    currentTab = tab;

    if (currentTab && currentTab.url) {
        let host = '';
        try { host = new URL(currentTab.url).hostname.toLowerCase(); } catch(e) {}
        const isSocial = SOCIAL_DOMAINS.some(d => host.endsWith(d));

        if (isSocial) {
            // Sembunyikan dropdown streaming mentah untuk sosial media agar bersih
            $('source-dropdown-group').style.display = 'none';
            inspectPageMetadata(currentTab.url);
        } else {
            $('source-dropdown-group').style.display = 'block';
            refreshCandidates();
        }
    }

    // Periksa status server
    const info = await Config.getAppInfo();
    if (info.token) {
        chrome.runtime.sendMessage({ type: 'CHECK_SESSION', token: info.token }, (res) => {
            if (res && res.ok) {
                $('conn-dot').className = 'status-dot';
                $('conn-dot').title = 'Terhubung & Sesi Valid';
            } else {
                $('conn-dot').className = 'status-dot offline';
                $('conn-dot').title = 'Sesi perlu diperiksa';
            }
        });
    }

    loadJobsState();
})();
