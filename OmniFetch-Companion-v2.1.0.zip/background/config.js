export const BASE_URL = "https://dw.pmlab.id";

export class Config {
    static generateToken() {
        const rand = Array.from(crypto.getRandomValues(new Uint8Array(12)))
            .map(b => b.toString(16).padStart(2, '0')).join('');
        return 'omni' + rand;
    }

    static async getAppInfo() {
        const data = await chrome.storage.local.get(['app', 'token', 'auto_cookie_sync', 'cookie_domains']);
        
        // Migration: Jika ada alamat server lama di storage, migrasikan ke BASE_URL permanen
        if (data.app && data.app !== BASE_URL) {
            await chrome.storage.local.set({ app: BASE_URL });
        }

        const token = (typeof data.token === 'string' && data.token.trim()) ? data.token.trim() : null;

        return {
            url: BASE_URL,
            token: token,
            cookieSync: !!data.auto_cookie_sync,
            cookieDomains: Array.isArray(data.cookie_domains) ? data.cookie_domains : []
        };
    }
    
    static async ensureSessionToken() {
        const info = await this.getAppInfo();
        if (!info.token) {
            const newToken = this.generateToken();
            await this.setToken(newToken);
            return newToken;
        }
        return info.token;
    }

    static async setAppInfo(token, cookieSync, cookieDomains = null) {
        const update = { app: BASE_URL };
        if (token !== undefined) update.token = token ? token.trim() : '';
        if (cookieSync !== undefined) update.auto_cookie_sync = !!cookieSync;
        if (cookieDomains !== null) update.cookie_domains = cookieDomains;
        await chrome.storage.local.set(update);
    }

    static async setToken(token) {
        await chrome.storage.local.set({ token: token ? token.trim() : '' });
    }
}

