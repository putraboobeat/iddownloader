// Universal Media Detector & Registry
export class Detector {
    static TTL = 3600000; // 1 jam

    static isAdOrAnalytics(url) {
        const lower = url.toLowerCase();
        const adPatterns = [
            'doubleclick.net', 'googlesyndication.com', 'googleads', '/pagead/',
            'adnxs.com', 'adsystem', 'popads', 'adsterra', 'scorecardresearch.com',
            '/telemetry', '/analytics', '/beacon', '/metrics', '/event-collector',
            '/tr/pixel', 'facebook.com/tr', 'tiktok.com/api/v1/pixel'
        ];
        return adPatterns.some(p => lower.includes(p));
    }

    static initialClassify(url, mime = '') {
        try {
            const u = new URL(url);
            const path = u.pathname.toLowerCase();
            const fullLower = url.toLowerCase();
            
            // 0. Filter iklan dan pelacak analitik
            if (this.isAdOrAnalytics(fullLower)) {
                return { kind: 'non_media', statusLabel: 'Bukan media (Iklan/Analitik)', isMedia: false, verified: true };
            }

            // 1. Subtitles
            if (/\.(vtt|srt)$/.test(path) || mime.includes('text/vtt')) {
                let subLabel = 'Subtitle';
                if (path.includes('/id/') || path.includes('/indonesian') || path.includes('/indonesia') || path.includes('_id.')) {
                    subLabel = 'Subtitle Indonesia';
                } else if (path.includes('/en/') || path.includes('/english') || path.includes('_en.')) {
                    subLabel = 'Subtitle Inggris';
                }
                return { kind: 'subtitle', statusLabel: subLabel, isMedia: true, verified: true };
            }

            // 1b. Segment HLS / DASH / Fragmen (Abaikan agar tidak memenuhi daftar)
            if (/\.(ts|m4s|mp4a|mp4v)$/.test(path) || mime.includes('video/mp2t') || /\/seg-\d+/.test(path)) {
                return { kind: 'segment', statusLabel: 'Segment', isMedia: false, verified: false };
            }

            // 2. Player Config JSON (misal config-*.json di Idlix / Majorplay)
            // config-*.json TIDAK boleh otomatis dianggap HLS terverifikasi hanya berdasarkan nama
            if (/\/config-[^/]+\.json$/.test(path) || (path.includes('config-') && path.endsWith('.json'))) {
                return { kind: 'unverified', statusLabel: 'Player Config (Perlu Verifikasi)', isMedia: false, verified: false };
            }

            // 3. HLS Playlist (Pasti jika berekstensi .m3u8 atau mime)
            if (/\.m3u8$/.test(path) || mime.includes('mpegurl') || mime.includes('x-mpegurl')) {
                const label = fullLower.includes('master') ? 'Playlist HLS (Master)' : 'Playlist HLS';
                return { kind: 'hls', statusLabel: label, isMedia: true, verified: true };
            }
            
            // 4. DASH Manifest (Pasti jika .mpd)
            if (/\.mpd$/.test(path) || mime.includes('dash+xml')) {
                return { kind: 'dash', statusLabel: 'Manifest DASH', isMedia: true, verified: true };
            }
            
            // 5. Video Langsung (Pasti)
            if (/\.(mp4|webm|mov|mkv)$/.test(path) || (mime.startsWith('video/') && !mime.includes('mp2t'))) {
                return { kind: 'video', statusLabel: 'Video langsung', isMedia: true, verified: true };
            }

            // 6. Audio Langsung (Pasti)
            if (/\.(mp3|wav|ogg|m4a|aac|flac)$/.test(path) || mime.startsWith('audio/')) {
                return { kind: 'audio', statusLabel: 'Audio langsung', isMedia: true, verified: true };
            }

            // 7. Endpoint token claim murni -> Tandai sebagai Bukan media
            if (path.includes('/claim')) {
                return { kind: 'non_media', statusLabel: 'Bukan media', isMedia: false, verified: true };
            }

            // 8. JSON, AJAX, config atau teks streaming lainnya -> Belum diverifikasi
            if (mime.includes('json') || path.endsWith('.json') || mime.includes('text/plain') || mime.includes('octet-stream') || path.includes('stream') || path.includes('play') || path.includes('video') || path.includes('config')) {
                return { kind: 'unverified', statusLabel: 'Belum diverifikasi', isMedia: false, verified: false };
            }
        } catch (e) {}

        return null;
    }

    static verifyCandidateContent(candidate, snippet = '') {
        if (!snippet) return candidate;
        
        // Cek HLS
        if (snippet.startsWith('#EXTM3U') || snippet.includes('#EXT-X-STREAM-INF') || snippet.includes('#EXT-X-TARGETDURATION')) {
            candidate.kind = 'hls';
            candidate.statusLabel = snippet.includes('#EXT-X-STREAM-INF') ? 'Playlist HLS (Master)' : 'Playlist HLS';
            candidate.isMedia = true;
            candidate.verified = true;
            return candidate;
        }

        // Cek DASH
        if (snippet.includes('<MPD') || snippet.includes('<mpd')) {
            candidate.kind = 'dash';
            candidate.statusLabel = 'Manifest DASH';
            candidate.isMedia = true;
            candidate.verified = true;
            return candidate;
        }

        // Cek JSON
        try {
            const parsed = JSON.parse(snippet);
            const mediaUrl = this.extractMediaUrlFromJson(parsed);
            if (mediaUrl) {
                candidate.kind = 'hls';
                candidate.statusLabel = 'Playlist HLS';
                candidate.extractedMediaUrl = mediaUrl;
                candidate.isMedia = true;
                candidate.verified = true;
                return candidate;
            }
            if (parsed && typeof parsed === 'object') {
                const keys = Object.keys(parsed).map(k => k.toLowerCase());
                if (keys.includes('claim')) {
                    candidate.kind = 'non_media';
                    candidate.statusLabel = 'Bukan media';
                    candidate.isMedia = false;
                    candidate.verified = true;
                    return candidate;
                }
            }
        } catch(e) {}

        return candidate;
    }

    /**
     * Memeriksa konten kandidat secara non-blocking di latar belakang.
     * Menggunakan ReadableStream reader untuk membatasi ukuran bacaan maksimal 8KB.
     */
    static async verifyCandidateContentAsync(tabId, cleanUrl) {
        try {
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 4000);

            const res = await fetch(cleanUrl, {
                method: 'GET',
                headers: { 'Range': 'bytes=0-8192' },
                signal: controller.signal
            });
            clearTimeout(timeoutId);

            if (!res.ok && res.status !== 206) return;

            let snippet = '';
            if (res.body && typeof res.body.getReader === 'function') {
                const reader = res.body.getReader();
                const decoder = new TextDecoder('utf-8');
                let bytesRead = 0;
                const MAX_BYTES = 8192;
                try {
                    while (bytesRead < MAX_BYTES) {
                        const { done, value } = await reader.read();
                        if (done) break;
                        snippet += decoder.decode(value, { stream: true });
                        bytesRead += value.length;
                        if (bytesRead >= MAX_BYTES) {
                            await reader.cancel();
                            break;
                        }
                    }
                } catch (readErr) {
                    // Ignore stream interruption
                }
            } else {
                const raw = await res.text();
                snippet = raw.slice(0, 8192);
            }

            snippet = snippet.trim();
            if (!snippet) return;

            const key = `tab:${tabId}`;
            const data = await chrome.storage.session.get(key);
            let items = data[key] || [];
            const idx = items.findIndex(x => x.url === cleanUrl);
            if (idx === -1) return;

            // Simpan cuplikan snippet aman untuk preview pengguna
            items[idx].previewSnippet = snippet.slice(0, 1024);

            const updatedCandidate = this.verifyCandidateContent(items[idx], snippet);
            items[idx] = updatedCandidate;

            await chrome.storage.session.set({ [key]: items });

            // Perbarui badge
            const mediaCount = items.filter(x => x.kind !== 'subtitle' && x.isMedia).length;
            if (mediaCount > 0) {
                await chrome.action.setBadgeBackgroundColor({ color: '#15803d', tabId });
                await chrome.action.setBadgeText({ text: String(mediaCount), tabId });
            }
        } catch (e) {
            // Abaikan kegagalan verifikasi latar belakang
        }
    }

    /**
     * Ekstraksi URL media dari objek JSON.
     * Tidak menerima semua HTTP URL, hanya URL yang memiliki format media atau stream valid.
     */
    static extractMediaUrlFromJson(data) {
        if (!data || typeof data !== 'object') return null;

        const isMediaLikeUrl = (str) => {
            if (typeof str !== 'string' || !str.startsWith('http')) return false;
            const lower = str.toLowerCase();
            return (
                lower.includes('.m3u8') ||
                lower.includes('.mpd') ||
                lower.includes('.mp4') ||
                lower.includes('.webm') ||
                lower.includes('.mkv') ||
                lower.includes('.m4a') ||
                lower.includes('/hls/') ||
                lower.includes('/dash/') ||
                lower.includes('manifest') ||
                lower.includes('master.m3u8')
            );
        };

        const candidatesToCheck = [
            data.file, data.url, data.src, data.stream, data.video, data.playbackUrl, data.manifest
        ];

        for (const c of candidatesToCheck) {
            if (isMediaLikeUrl(c)) return c;
        }

        if (Array.isArray(data.sources)) {
            for (const s of data.sources) {
                const sUrl = s?.file || s?.src || s?.url;
                if (isMediaLikeUrl(sUrl)) return sUrl;
            }
        }

        return null;
    }

    static async addCandidate(tabId, url, mime = '', referer = '', type = 'network', extraMeta = {}) {
        if (tabId < 0) return;
        
        // Pertahankan query parameters & signed token, hanya bersihkan hash fragmen
        const cleanUrl = url.split('#')[0]; 
        
        const classification = this.initialClassify(cleanUrl, mime);
        if (!classification || classification.kind === 'segment') return;

        const key = `tab:${tabId}`;
        const data = await chrome.storage.session.get(key);
        let items = data[key] || [];
        
        const now = Date.now();
        
        let displayTitle = '';
        try {
            const parsed = new URL(cleanUrl);
            const pathSegments = parsed.pathname.split('/').filter(Boolean);
            displayTitle = pathSegments.pop() || parsed.hostname;
        } catch(e) {
            displayTitle = cleanUrl.slice(0, 30);
        }

        const cand = {
            id: 'cand_' + Math.random().toString(36).substr(2, 9),
            url: cleanUrl,
            displayTitle: displayTitle,
            kind: classification.kind,
            statusLabel: classification.statusLabel,
            isMedia: classification.isMedia,
            verified: classification.verified,
            sourceType: type,
            time: now,
            referer: referer || '',
            meta: extraMeta
        };

        // Simpan kandidat langsung agar tidak hilang dari daftar UI
        const existingIndex = items.findIndex(x => x.url === cleanUrl);
        if (existingIndex >= 0) {
            items[existingIndex].time = now;
            items[existingIndex].kind = cand.kind;
            items[existingIndex].statusLabel = cand.statusLabel;
            items[existingIndex].isMedia = cand.isMedia;
            items[existingIndex].verified = cand.verified;
        } else {
            items.push(cand);
        }

        // Bersihkan item kedaluwarsa
        items = items.filter(x => (now - x.time) < this.TTL);

        // Maksimal 50 kandidat per tab
        items = items.slice(-50);
        await chrome.storage.session.set({ [key]: items });

        // Update badge untuk item yang terdeteksi
        const mediaCount = items.filter(x => x.kind !== 'subtitle' && x.isMedia).length;
        if (mediaCount > 0) {
            await chrome.action.setBadgeBackgroundColor({ color: '#15803d', tabId });
            await chrome.action.setBadgeText({ text: String(mediaCount), tabId });
        } else {
            await chrome.action.setBadgeText({ text: '', tabId });
        }

        // Jalankan verifikasi konten di latar belakang tanpa memblokir antrean
        if (!cand.verified && cand.kind === 'unverified') {
            this.verifyCandidateContentAsync(tabId, cleanUrl).catch(() => {});
        }
        
        return items.length;
    }

    static async clear(tabId) {
        await chrome.storage.session.remove(`tab:${tabId}`);
        await chrome.action.setBadgeText({ text: '', tabId });
    }
    
    static async getCandidates(tabId) {
        const key = `tab:${tabId}`;
        const data = await chrome.storage.session.get(key);
        return data[key] || [];
    }

    /**
     * Memilih kandidat media terbaik secara cerdas.
     * Menghindari iklan dan memprioritaskan HLS Master > HLS/DASH > Direct MP4 > Audio.
     */
    static findBestMedia(items = []) {
        if (!items || items.length === 0) return null;

        const mediaItems = items.filter(x => x.kind !== 'subtitle' && x.isMedia);
        if (mediaItems.length === 0) {
            // Fallback ke unverified jika tidak ada media pasti
            return items.find(x => x.kind !== 'subtitle' && x.kind !== 'non_media') || null;
        }

        const score = x => {
            let s = 0;
            const fullLower = (x.url || '').toLowerCase();
            if (this.isAdOrAnalytics(fullLower)) return -999;
            if (x.statusLabel?.includes('Master')) s += 60;
            else if (x.kind === 'hls') s += 50;
            else if (x.kind === 'dash') s += 45;
            else if (x.kind === 'video') s += 40;
            else if (x.kind === 'audio') s += 25;
            else if (x.kind === 'unverified') s += 10;

            // Prioritaskan sumber dari DOM jika ada
            if (x.sourceType === 'dom') s += 2;
            return s;
        };

        const sorted = [...mediaItems].sort((a, b) => score(b) - score(a) || (b.time - a.time));
        return sorted[0] || null;
    }

    /**
     * Otomatis mendeteksi subtitle Indonesia yang cocok dengan media saat ini.
     * Mengkorelasikan hostname dan segment path agar tidak salah memasangkan subtitle
     * dari video/tab yang berbeda.
     */
    static findDefaultSubtitle(items = [], currentVideoUrl = '') {
        if (!items || items.length === 0) return null;
        const subs = items.filter(x => x.kind === 'subtitle');
        if (subs.length === 0) return null;

        let candidateSubs = [];
        if (currentVideoUrl) {
            try {
                const vidUrl = new URL(currentVideoUrl);
                const vidHost = vidUrl.hostname.toLowerCase();
                const vidPathParts = vidUrl.pathname.split('/').filter(p => p.length > 3);

                // Cari subtitle yang satu domain atau memiliki kesamaan path segment
                candidateSubs = subs.filter(s => {
                    try {
                        const sUrl = new URL(s.url);
                        if (sUrl.hostname.toLowerCase() === vidHost) {
                            // Jika ada segment unik di video, periksa kecocokan
                            if (vidPathParts.length > 0) {
                                return vidPathParts.some(p => sUrl.pathname.includes(p));
                            }
                            return true;
                        }
                        return false;
                    } catch (e) {
                        return false;
                    }
                });
            } catch (e) {
                candidateSubs = [];
            }
        } else {
            candidateSubs = subs;
        }

        // Jika ada currentVideoUrl tetapi tidak ada subtitle yang cocok dengan video tersebut,
        // jangan pasangkan subtitle dari video/film sebelumnya!
        if (candidateSubs.length === 0) return null;

        // Cari yang bertanda Indonesia
        const idSub = candidateSubs.find(s => {
            const p = (s.url + ' ' + (s.statusLabel || '')).toLowerCase();
            return p.includes('indonesia') || p.includes('/id/') || p.includes('_id.') || p.includes('bahasa');
        });

        return idSub || candidateSubs[0] || null;
    }
}
