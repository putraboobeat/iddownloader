import { BASE_URL, Config } from './config.js';
import { APIClient } from './api.js';
import { convertVttToSrt } from '../utils/subtitle.js';

const WINDOWS_RESERVED = new Set([
    'CON', 'PRN', 'AUX', 'NUL',
    'COM1', 'COM2', 'COM3', 'COM4', 'COM5', 'COM6', 'COM7', 'COM8', 'COM9',
    'LPT1', 'LPT2', 'LPT3', 'LPT4', 'LPT5', 'LPT6', 'LPT7', 'LPT8', 'LPT9'
]);

export class JobManager {
    static isPolling = false;
    static _lock = Promise.resolve();

    /**
     * Serialisasi mutasi storage untuk mencegah race condition antara
     * polling status, stop request, dan event onChanged unduhan.
     */
    static async withLock(fn) {
        const run = async () => {
            return await fn();
        };
        const next = this._lock.then(run, run);
        this._lock = next.catch(() => {});
        return next;
    }

    static sanitizeFolderName(name) {
        if (!name || typeof name !== 'string') return 'Media';
        let clean = name.replace(/[\\/:*?"<>|\r\n\t]/g, '_').trim();
        clean = clean.replace(/^\.+|\.+$/g, '').trim();
        if (!clean || WINDOWS_RESERVED.has(clean.toUpperCase())) {
            clean = 'Media_' + Math.random().toString(36).slice(2, 6);
        }
        return clean.slice(0, 60).trim() || 'Media';
    }

    static sanitizeFileName(name, defaultExt = '.mp4') {
        if (!name || typeof name !== 'string') return 'video' + defaultExt;
        
        let ext = defaultExt;
        let base = name.trim();
        const lastDot = base.lastIndexOf('.');
        if (lastDot > 0) {
            const rawExt = base.slice(lastDot).toLowerCase().replace(/[\\/:*?"<>|\r\n\t\s]/g, '');
            if (rawExt.length >= 2 && rawExt.length <= 10) {
                ext = rawExt;
                base = base.slice(0, lastDot);
            }
        }

        base = base.replace(/[\\/:*?"<>|\r\n\t]/g, '_').trim();
        base = base.replace(/^\.+|\.+$/g, '').trim();

        if (!base || WINDOWS_RESERVED.has(base.toUpperCase())) {
            base = 'file_' + Math.random().toString(36).slice(2, 7);
        }

        // Pertahankan ekstensi file, batasi hanya panjang basename
        base = base.slice(0, 60).trim();
        return `${base}${ext}`;
    }

    static async getJobs() {
        const data = await chrome.storage.local.get(['omni_jobs', 'omni_active_job_id']);
        const rawJobs = data.omni_jobs || {};
        // Deep clone untuk menghindari mutasi referensi objek langsung
        const clonedJobs = JSON.parse(JSON.stringify(rawJobs));
        return {
            jobs: clonedJobs,
            activeJobId: data.omni_active_job_id || null
        };
    }

    static async saveJobs(jobs, activeJobId = undefined) {
        const update = { omni_jobs: jobs };
        if (activeJobId !== undefined) {
            update.omni_active_job_id = activeJobId;
        }
        await chrome.storage.local.set(update);
    }

    /**
     * Mendaftarkan pekerjaan baru dengan mengikat token sesi pengguna secara persisten.
     */
    static async addJob(jobId, payload, title = 'Media', sessionToken = null) {
        return await this.withLock(async () => {
            let token = sessionToken;
            if (!token) {
                const info = await Config.getAppInfo();
                token = info.token || '';
            }

            const { jobs } = await this.getJobs();
            const now = Date.now();
            const cleanFolder = this.sanitizeFolderName(title || 'Media Video');

            const newJob = {
                id: jobId,
                sessionToken: token, // Terikat pada sesi saat pekerjaan dibuat
                title: cleanFolder,
                url: payload.urls || payload.url || '',
                payload: payload,
                status: 'queued',
                stageLabel: 'Diterima server (Menunggu antrean)…',
                percent: 0,
                speed: '',
                eta: '',
                logs: [],
                files: [],
                preferZip: !!payload.prefer_zip,
                downloadTriggered: false,
                downloadStatus: 'pending',
                createdAt: now,
                updatedAt: now,
                lastPollTime: now,
                lastPollError: null,
                error: null
            };

            const jobKeys = Object.keys(jobs);
            if (jobKeys.length > 30) {
                const oldestKey = jobKeys.sort((a, b) => jobs[a].createdAt - jobs[b].createdAt)[0];
                delete jobs[oldestKey];
            }

            jobs[jobId] = newJob;
            await this.saveJobs(jobs, jobId);

            this.startPollingLoop();
            return newJob;
        });
    }

    static async updateJob(jobId, updates) {
        return await this.withLock(async () => {
            const { jobs } = await this.getJobs();
            if (!jobs[jobId]) return null;
            Object.assign(jobs[jobId], updates, { updatedAt: Date.now() });
            await this.saveJobs(jobs);
            return jobs[jobId];
        });
    }

    static startPollingLoop() {
        if (this.isPolling) return;
        this.isPolling = true;

        let backoffDelay = 2000;

        const loop = async () => {
            try {
                const { jobs } = await this.getJobs();
                const activeJobs = Object.values(jobs).filter(j => 
                    ['queued', 'downloading', 'validating', 'saving'].includes(j.status)
                );

                if (activeJobs.length === 0) {
                    this.isPolling = false;
                    return;
                }

                for (const job of activeJobs) {
                    if (job.status === 'saving') {
                        // Rekonsiliasi unduhan lokal yang sedang berjalan di Chrome
                        await this.reconcileJobDownloads(job.id);
                        continue;
                    }

                    try {
                        const statusData = await APIClient.getJobStatus(job.id, job.sessionToken);
                        await this.processJobStatusUpdate(job.id, statusData);
                        backoffDelay = 2000; // Reset backoff jika sukses
                    } catch (err) {
                        const now = Date.now();
                        if (err.code === 'JOB_NOT_FOUND') {
                            await this.updateJob(job.id, {
                                status: 'failed',
                                stageLabel: 'Pekerjaan tidak ditemukan di server dw.pmlab.id.',
                                lastPollTime: now,
                                lastPollError: 'Pekerjaan tidak ditemukan (404)',
                                error: 'Job not found'
                            });
                        } else if (err.code === 'AUTH_EXPIRED') {
                            await this.updateJob(job.id, {
                                status: 'failed',
                                stageLabel: 'Sesi ditolak oleh server (401 Unauthorized).',
                                lastPollTime: now,
                                lastPollError: 'Sesi ditolak (401)',
                                error: 'AUTH_EXPIRED'
                            });
                        } else {
                            // Catat error jaringan/server dan terapkan backoff
                            await this.updateJob(job.id, {
                                lastPollTime: now,
                                lastPollError: err.message || 'Koneksi terputus'
                            });
                            backoffDelay = Math.min(12000, backoffDelay * 1.5);
                        }
                    }
                }
            } catch (loopErr) {
                // Abaikan kesalahan loop umum
            }

            if (this.isPolling) {
                setTimeout(loop, backoffDelay);
            }
        };

        loop();
    }

    static async processJobStatusUpdate(jobId, data) {
        return await this.withLock(async () => {
            const { jobs } = await this.getJobs();
            const job = jobs[jobId];
            if (!job) return;

            // Jika pekerjaan sudah dibatalkan atau selesai secara lokal, jangan timpa
            if (job.status === 'cancelled') return;

            const serverStatus = data.status || '';
            let stageLabel = job.stageLabel;
            let percent = typeof data.percent === 'number' ? data.percent : job.percent;
            let speed = '';
            let eta = '';

            if (serverStatus.includes('|')) {
                const parts = serverStatus.split('|');
                if (parts.length >= 2) speed = parts[1].trim();
                if (parts.length >= 3) eta = parts[2].trim();
            }

            if (serverStatus === 'queued') {
                stageLabel = 'Diterima server (Dalam antrean)…';
            } else if (serverStatus === 'downloading' || serverStatus.includes('Mengunduh') || serverStatus.includes('Menghubungi')) {
                const speedEtaText = [speed, eta].filter(Boolean).join(' | ');
                stageLabel = `Diproses server (${percent}%${speedEtaText ? ' • ' + speedEtaText : ''})`;
            } else if (serverStatus === 'validating' || serverStatus.includes('Menggabungkan')) {
                stageLabel = 'Menggabungkan & memvalidasi media di server…';
                percent = 98;
            }

            if (serverStatus === 'completed' || (!data.running && serverStatus === 'completed')) {
                percent = 100;
                const incomingFiles = Array.isArray(data.files) ? data.files : [];
                
                // Siapkan daftar file terstruktur jika belum ada
                const structuredFiles = this.prepareStructuredFiles(job, incomingFiles);

                jobs[jobId].percent = 100;
                jobs[jobId].logs = data.logs || job.logs;
                jobs[jobId].files = structuredFiles;
                jobs[jobId].status = 'saving';
                jobs[jobId].stageLabel = 'Memulai penyimpanan hasil ke komputer…';
                jobs[jobId].updatedAt = Date.now();
                await this.saveJobs(jobs);

                // Mulai download file ke komputer
                await this._executeSaveFilesToDisk(jobs[jobId], structuredFiles, { onlyFailed: false }, jobs);
                return;
            }

            if (serverStatus === 'failed') {
                const lastLog = (data.logs && data.logs.length > 0) ? data.logs[data.logs.length - 1] : 'Unduhan gagal di server';
                jobs[jobId].status = 'failed';
                jobs[jobId].stageLabel = `Gagal di server: ${lastLog}`;
                jobs[jobId].logs = data.logs || job.logs;
                jobs[jobId].error = lastLog;
                jobs[jobId].updatedAt = Date.now();
                await this.saveJobs(jobs);
                return;
            }

            if (serverStatus === 'cancelled') {
                jobs[jobId].status = 'cancelled';
                jobs[jobId].stageLabel = 'Dibatalkan oleh server.';
                jobs[jobId].logs = data.logs || job.logs;
                jobs[jobId].updatedAt = Date.now();
                await this.saveJobs(jobs);
                return;
            }

            jobs[jobId].percent = percent;
            jobs[jobId].speed = speed;
            jobs[jobId].eta = eta;
            jobs[jobId].stageLabel = stageLabel;
            jobs[jobId].status = data.running ? 'downloading' : job.status;
            jobs[jobId].logs = data.logs || job.logs;
            jobs[jobId].updatedAt = Date.now();
            await this.saveJobs(jobs);
        });
    }

    /**
     * Mempersiapkan daftar file yang diharapkan dengan nama dan path bersih.
     */
    static prepareStructuredFiles(job, incomingFiles = []) {
        const folderTitle = this.sanitizeFolderName(job.title || 'Media');
        const hasZip = incomingFiles.some(f => f.is_zip || f.name?.endsWith('.zip'));
        const nonZipCount = incomingFiles.filter(f => !f.is_zip && !f.name?.endsWith('.zip')).length;

        // Tentukan apakah mendownload ZIP atau file individual
        // Default: jika ada ZIP dan ada file individual, unduh file individual saja agar tidak menggandakan ukuran
        let selectedFiles = incomingFiles;
        if (hasZip && nonZipCount > 0) {
            if (job.preferZip) {
                selectedFiles = incomingFiles.filter(f => f.is_zip || f.name?.endsWith('.zip'));
            } else {
                selectedFiles = incomingFiles.filter(f => !f.is_zip && !f.name?.endsWith('.zip'));
            }
        }

        // Selaraskan nama dasar subtitle dengan video utama jika memungkinkan
        let mainVideoBase = '';
        const videoFile = selectedFiles.find(f => /\.(mp4|mkv|webm|mov)$/i.test(f.name));
        if (videoFile) {
            const dot = videoFile.name.lastIndexOf('.');
            mainVideoBase = dot > 0 ? videoFile.name.slice(0, dot) : videoFile.name;
        }

        return selectedFiles.map(f => {
            let finalName = f.name;
            // Jika ada video utama dan file ini adalah subtitle, selaraskan nama depannya
            if (mainVideoBase && /\.(srt|vtt)$/i.test(f.name)) {
                const subExt = f.name.slice(f.name.lastIndexOf('.'));
                const langMatch = f.name.match(/\.(id|en|in|indonesia|eng)\./i);
                const langTag = langMatch ? `.${langMatch[1].toLowerCase()}` : '';
                finalName = `${mainVideoBase}${langTag}${subExt}`;
            }

            const cleanFileName = this.sanitizeFileName(finalName);
            const targetPath = `OmniFetch/${folderTitle}/${cleanFileName}`;

            return {
                name: f.name,
                cleanName: cleanFileName,
                targetPath: targetPath,
                url: f.url,
                isZip: !!(f.is_zip || f.name.endsWith('.zip')),
                size: f.size || 0,
                downloadId: null,
                status: 'pending', // 'pending' | 'downloading' | 'completed' | 'interrupted' | 'failed'
                bytesReceived: 0,
                totalBytes: f.size || 0,
                error: null
            };
        });
    }

    /**
     * Mengunduh file hasil pekerjaan ke komputer pengguna.
     * Mencatat status per-file secara langsung dan menangani kegagalan parsial.
     */
    static async saveFilesToDisk(jobId, filesToSave = null, options = { onlyFailed: false }) {
        return await this.withLock(async () => {
            const { jobs } = await this.getJobs();
            const job = jobs[jobId];
            if (!job) return;
            await this._executeSaveFilesToDisk(job, filesToSave, options, jobs);
        });
    }

    /**
     * Pelaksana internal penyimpanan file ke komputer.
     * Dipanggil dengan asumsi lock storage telah dipegang oleh pemanggil.
     */
    static async _executeSaveFilesToDisk(job, filesToSave = null, options = { onlyFailed: false }, jobsObj = null) {
        let files = Array.isArray(filesToSave) && filesToSave.length > 0 ? filesToSave : job.files;
        if (!files || files.length === 0) {
            job.status = 'failed';
            job.downloadStatus = 'failed';
            job.stageLabel = 'Gagal menyimpan ke komputer: Tidak ada file hasil dari server.';
            job.error = 'NO_FILES';
            if (jobsObj) await this.saveJobs(jobsObj);
            return;
        }

        const sessionToken = job.sessionToken || '';
        const folderTitle = this.sanitizeFolderName(job.title || 'Media');

        job.downloadTriggered = true;
        job.status = 'saving';
        job.stageLabel = `Menyimpan hasil ke komputer (Downloads/OmniFetch/${folderTitle}/)…`;
        if (jobsObj) await this.saveJobs(jobsObj);

        let startedCount = 0;
        let failureReasons = [];

        // Cek apakah ada file SRT yang sudah tersedia
        const hasSrtAlready = files.some(other => other.name && other.name.toLowerCase().endsWith('.srt'));

        for (let i = 0; i < files.length; i++) {
            const f = files[i];

            // Cek rekonsiliasi dengan file yang sudah tercatat di job
            const existingFile = Array.isArray(job.files) ? job.files.find(existing => 
                existing === f ||
                existing.url === f.url || 
                (existing.cleanName && (existing.cleanName === f.cleanName || existing.cleanName === f.name))
            ) : null;

            if (existingFile && existingFile.downloadId) {
                f.downloadId = existingFile.downloadId;
                if (!f.status || f.status === 'pending') {
                    f.status = existingFile.status;
                }
                f.targetPath = f.targetPath || existingFile.targetPath;
                f.cleanName = f.cleanName || existingFile.cleanName;
            }

            // 1. Pencegahan duplikat: Jika file sudah selesai atau sedang diunduh, lewati
            if (f.downloadId && (f.status === 'completed' || f.status === 'downloading')) {
                startedCount++;
                continue;
            }

            // Jika mode retry hanya file yang gagal, lewati file yang sudah berstatus sukses
            if (options.onlyFailed && f.status === 'completed') {
                continue;
            }

            try {
                const fileRelUrl = f.url;
                if (!fileRelUrl || typeof fileRelUrl !== 'string') {
                    f.status = 'failed';
                    f.error = 'URL file kosong';
                    failureReasons.push('URL file tidak valid');
                    continue;
                }

                // Bangun URL unduhan lengkap
                let fullUrl = fileRelUrl.startsWith('http') ? fileRelUrl : new URL(fileRelUrl, BASE_URL).href;

                // Keamanan: Validasi bahwa URL unduhan mengarah ke path /download/ di BASE_URL
                if (!fullUrl.startsWith(`${BASE_URL}/download/`)) {
                    f.status = 'failed';
                    f.error = 'URL di luar origin server yang diizinkan';
                    failureReasons.push('URL di luar server');
                    continue;
                }

                // Masukkan token sesi pekerjaan ke query string jika belum ada
                if (sessionToken && !fullUrl.includes('session=')) {
                    const joiner = fullUrl.includes('?') ? '&' : '?';
                    fullUrl += `${joiner}session=${encodeURIComponent(sessionToken)}`;
                }

                let downloadUrlToUse = fullUrl;
                let targetFileName = f.cleanName || this.sanitizeFileName(f.name);
                let targetPath = f.targetPath || `OmniFetch/${folderTitle}/${targetFileName}`;

                // Konversi VTT ke SRT jika file berupa WebVTT dan belum ada file SRT
                const isVtt = f.name && f.name.toLowerCase().endsWith('.vtt');
                if (isVtt && !hasSrtAlready) {
                    try {
                        const vttController = new AbortController();
                        const vttTimer = setTimeout(() => vttController.abort(), 6000);
                        const vttRes = await fetch(fullUrl, { signal: vttController.signal });
                        clearTimeout(vttTimer);

                        if (vttRes.ok) {
                            const vttText = await vttRes.text();
                            if (vttText && (vttText.includes('WEBVTT') || vttText.includes('-->'))) {
                                const convertedSrt = convertVttToSrt(vttText);
                                if (convertedSrt && convertedSrt.length > 10) {
                                    downloadUrlToUse = 'data:text/plain;charset=utf-8,' + encodeURIComponent(convertedSrt);
                                    targetFileName = targetFileName.replace(/\.vtt$/i, '.srt');
                                    targetPath = `OmniFetch/${folderTitle}/${targetFileName}`;
                                    f.cleanName = targetFileName;
                                    f.targetPath = targetPath;
                                }
                            }
                        }
                    } catch (e) {
                        // Jika fetch atau konversi gagal, tetap unduh file .vtt asli
                    }
                }

                if (chrome.downloads && typeof chrome.downloads.download === 'function') {
                    const dlId = await chrome.downloads.download({
                        url: downloadUrlToUse,
                        filename: targetPath,
                        conflictAction: 'uniquify',
                        saveAs: false
                    });

                    f.downloadId = dlId;
                    f.status = 'downloading';
                    startedCount++;
                } else {
                    f.status = 'failed';
                    f.error = 'Chrome Downloads API tidak tersedia';
                    failureReasons.push('Downloads API tidak tersedia');
                }
            } catch (dlErr) {
                f.status = 'failed';
                f.error = dlErr.message || 'Gagal memulai unduhan Chrome';
                failureReasons.push(f.error);
            }

            // Simpan status per-file secara langsung agar tidak hilang saat worker terhenti
            job.files = files;
            if (jobsObj) await this.saveJobs(jobsObj);
        }

        // Evaluasi setelah seluruh file dicoba
        const allFilesFailed = files.every(f => f.status === 'failed');
        if (allFilesFailed || startedCount === 0) {
            job.status = 'failed';
            job.downloadStatus = 'failed';
            job.stageLabel = `Gagal menyimpan ke komputer: ${failureReasons[0] || 'Tidak dapat memulai transfer file'}`;
            job.error = failureReasons.join('; ');
            if (jobsObj) await this.saveJobs(jobsObj);
            return;
        }

        const someFailed = files.some(f => f.status === 'failed');
        if (someFailed) {
            job.stageLabel = `Menyimpan ke komputer (${startedCount}/${files.length} file berjalan)…`;
        } else {
            job.stageLabel = `Menyimpan ${startedCount} file ke komputer (Downloads/OmniFetch/${folderTitle}/)…`;
        }

        job.files = files;
        if (jobsObj) await this.saveJobs(jobsObj);
    }

    /**
     * Memproses event perubahan status dari Chrome Downloads API.
     */
    static async handleDownloadDelta(delta) {
        if (!delta || !delta.id) return;

        return await this.withLock(async () => {
            const { jobs } = await this.getJobs();

            for (const job of Object.values(jobs)) {
                if (!Array.isArray(job.files)) continue;

                const file = job.files.find(f => f.downloadId === delta.id);
                if (!file) continue;

                // Perbarui ukuran transfer jika tersedia dari delta
                if (delta.bytesReceived && typeof delta.bytesReceived.current === 'number') {
                    file.bytesReceived = delta.bytesReceived.current;
                }
                if (delta.totalBytes && typeof delta.totalBytes.current === 'number') {
                    file.totalBytes = delta.totalBytes.current;
                }

                if (delta.state && delta.state.current === 'complete') {
                    file.status = 'completed';
                    file.error = null;
                } else if (delta.state && delta.state.current === 'interrupted') {
                    file.status = 'interrupted';
                    file.error = delta.error?.current || 'Unduhan dibatalkan atau jaringan terputus';
                }

                // Evaluasi status keseluruhan pekerjaan
                const totalCount = job.files.length;
                const completedCount = job.files.filter(f => f.status === 'completed').length;
                const interruptedCount = job.files.filter(f => f.status === 'interrupted' || f.status === 'failed').length;
                const downloadingCount = job.files.filter(f => f.status === 'downloading' || f.status === 'pending').length;

                const folderTitle = this.sanitizeFolderName(job.title || 'Media');

                if (completedCount === totalCount && totalCount > 0) {
                    job.status = 'completed';
                    job.downloadStatus = 'complete';
                    job.percent = 100;
                    job.stageLabel = `✅ Selesai! Tersimpan di Downloads/OmniFetch/${folderTitle}/`;
                } else if (downloadingCount === 0 && interruptedCount > 0) {
                    // Semua proses selesai dan ada yang gagal
                    job.status = 'failed';
                    job.downloadStatus = 'interrupted';
                    job.stageLabel = `⚠️ Unduhan komputer terputus (${interruptedCount}/${totalCount} file gagal). Klik Coba Lagi untuk mengulang.`;
                    job.error = file.error || 'Unduhan Chrome terputus';
                } else if (interruptedCount > 0) {
                    job.stageLabel = `Menyimpan ke komputer (${completedCount}/${totalCount} selesai, ada file tersendat)…`;
                } else {
                    // Tampilkan progres transfer nyata jika ada data byte
                    const totalReceived = job.files.reduce((acc, f) => acc + (f.bytesReceived || 0), 0);
                    const totalExpected = job.files.reduce((acc, f) => acc + (f.totalBytes || 0), 0);
                    if (totalExpected > 0) {
                        const localPct = Math.round((totalReceived / totalExpected) * 100);
                        const mbRec = (totalReceived / (1024 * 1024)).toFixed(1);
                        const mbTot = (totalExpected / (1024 * 1024)).toFixed(1);
                        job.stageLabel = `Menyimpan ke komputer: ${mbRec} MB / ${mbTot} MB (${localPct}%)`;
                    } else {
                        job.stageLabel = `Menyimpan ke komputer (Downloads/OmniFetch/${folderTitle}/)…`;
                    }
                }

                job.updatedAt = Date.now();
                await this.saveJobs(jobs);
                break;
            }
        });
    }

    /**
     * Rekonsiliasi unduhan aktif terhadap pencarian Chrome setelah browser/worker restart.
     */
    static async reconcileJobDownloads(jobId) {
        return await this.withLock(async () => {
            const { jobs } = await this.getJobs();
            const job = jobs[jobId];
            if (!job || !Array.isArray(job.files)) return;

            if (!chrome.downloads || typeof chrome.downloads.search !== 'function') return;

            let anyChange = false;
            for (const file of job.files) {
                if (file.downloadId && file.status === 'downloading') {
                    try {
                        const items = await chrome.downloads.search({ id: file.downloadId });
                        if (items && items.length > 0) {
                            const item = items[0];
                            if (item.state === 'complete' && file.status !== 'completed') {
                                file.status = 'completed';
                                anyChange = true;
                            } else if (item.state === 'interrupted' && file.status !== 'interrupted') {
                                file.status = 'interrupted';
                                file.error = item.error || 'Terputus';
                                anyChange = true;
                            }
                        } else {
                            // ID tidak ditemukan lagi di history Chrome
                            file.status = 'failed';
                            file.error = 'Download ID hilang';
                            anyChange = true;
                        }
                    } catch (e) {
                        // Jangan anggap berhasil jika pencarian gagal
                    }
                }
            }

            if (anyChange) {
                const total = job.files.length;
                const completed = job.files.filter(f => f.status === 'completed').length;
                const interrupted = job.files.filter(f => ['interrupted', 'failed'].includes(f.status)).length;
                const folderTitle = this.sanitizeFolderName(job.title || 'Media');

                if (completed === total && total > 0) {
                    job.status = 'completed';
                    job.downloadStatus = 'complete';
                    job.stageLabel = `✅ Selesai! Tersimpan di Downloads/OmniFetch/${folderTitle}/`;
                } else if (interrupted > 0 && job.files.every(f => f.status !== 'downloading')) {
                    job.status = 'failed';
                    job.downloadStatus = 'interrupted';
                    job.stageLabel = `⚠️ Unduhan komputer terputus (${interrupted}/${total} file gagal).`;
                }
                job.updatedAt = Date.now();
                await this.saveJobs(jobs);
            }
        });
    }

    /**
     * Menghentikan pekerjaan dengan verifikasi respons server terkonfirmasi.
     */
    static async stopJob(jobId) {
        return await this.withLock(async () => {
            const { jobs } = await this.getJobs();
            const job = jobs[jobId];
            if (!job) return { ok: false, error: 'Job not found' };

            // Batalkan unduhan Chrome lokal yang sedang berlangsung
            if (Array.isArray(job.files) && chrome.downloads && typeof chrome.downloads.cancel === 'function') {
                for (const f of job.files) {
                    if (f.downloadId && f.status === 'downloading') {
                        try {
                            await chrome.downloads.cancel(f.downloadId);
                        } catch (e) {}
                    }
                }
            }

            // Jika status masih dalam proses server, hubungi endpoint /api/stop dengan token sesi terikat
            if (['queued', 'downloading', 'validating'].includes(job.status)) {
                try {
                    job.stageLabel = 'Mengirim permintaan stop ke server dw.pmlab.id…';
                    await this.saveJobs(jobs);

                    const stopRes = await APIClient.stopJob(jobId, job.sessionToken);
                    if (stopRes && stopRes.status === 'cancelled') {
                        job.status = 'cancelled';
                        job.stageLabel = '⏹️ Dibatalkan oleh pengguna (Terkonfirmasi server).';
                        job.updatedAt = Date.now();
                        await this.saveJobs(jobs);
                        return { ok: true };
                    } else {
                        job.stageLabel = 'Server merespons stop tetapi status tidak berubah.';
                        await this.saveJobs(jobs);
                        return { ok: false, error: 'Server did not confirm cancellation' };
                    }
                } catch (err) {
                    job.stageLabel = `⚠️ Gagal menghentikan di server: ${err.message}`;
                    job.updatedAt = Date.now();
                    await this.saveJobs(jobs);
                    return { ok: false, error: err.message };
                }
            } else {
                // Pembatalan murni di sisi penyimpanan lokal
                job.status = 'cancelled';
                job.stageLabel = '⏹️ Unduhan lokal dibatalkan oleh pengguna.';
                job.updatedAt = Date.now();
                await this.saveJobs(jobs);
                return { ok: true };
            }
        });
    }

    /**
     * Mengulang unduhan:
     * - Jika transfer lokal yang gagal: mengulang hanya file yang gagal tanpa pengerjaan ulang server.
     * - Jika pengerjaan server yang gagal: mengirim pekerjaan baru ke backend.
     */
    static async retryJob(jobId) {
        const { jobs } = await this.getJobs();
        const job = jobs[jobId];
        if (!job) return { ok: false, error: 'Job not found' };

        // Kasus 1: File server sudah siap, tapi transfer ke komputer gagal/terputus
        if (Array.isArray(job.files) && job.files.length > 0 && ['saving', 'failed'].includes(job.status) && job.downloadStatus !== 'pending') {
            await this.saveFilesToDisk(jobId, job.files, { onlyFailed: true });
            return { ok: true, mode: 'local_files' };
        }

        // Kasus 2: Pekerjaan server gagal -> kirim ulang tugas baru
        try {
            const res = await APIClient.sendJob(job.payload, job.sessionToken);
            if (res && res.job_id) {
                const newJob = await this.addJob(res.job_id, job.payload, job.title, job.sessionToken);
                return { ok: true, mode: 'new_server_job', newJobId: res.job_id };
            }
            return { ok: false, error: 'Tidak mendapatkan Job ID baru' };
        } catch (e) {
            return { ok: false, error: e.message };
        }
    }
}
