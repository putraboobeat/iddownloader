(function() {
    'use strict';
    if (window.__omnifetch_injected) return;
    window.__omnifetch_injected = true;

    const HOST = location.hostname;
    const processedNodes = new WeakSet();

    const style = document.createElement('style');
    style.textContent = `
        .omni-btn {
            display: inline-flex; align-items: center; gap: 5px;
            background: linear-gradient(135deg, #c9153d, #ff3d58);
            color: #fff !important; border: none; border-radius: 20px;
            padding: 6px 13px; font-size: 12px; font-weight: 700;
            cursor: pointer; margin-left: 8px;
            font-family: -apple-system, sans-serif;
            text-decoration: none !important;
            transition: transform 0.1s, opacity 0.1s; z-index: 9999;
            box-shadow: 0 2px 8px rgba(201,21,61,0.35);
        }
        .omni-btn:hover { transform: scale(1.05); }
        .omni-btn:active { transform: scale(0.97); }
        .omni-btn svg { width: 12px; height: 12px; fill: currentColor; }
    `;
    document.head.appendChild(style);

    const arrowSVG = `<svg viewBox="0 0 24 24"><path d="M12 2v13m0 0l-4-4m4 4l4-4M4 19h16"/></svg>`;

    function sendToBackground(url, btn) {
        if (btn) { btn.innerHTML = '⏳...'; btn.disabled = true; }
        chrome.runtime.sendMessage({
            type: 'SEND_JOB',
            payload: { urls: url, mode: 'ytdlp', media_type: 'video', resolution: 'best' }
        }, (res) => {
            if (chrome.runtime.lastError || (res && res.error)) {
                if (btn) { btn.innerHTML = '❌ Gagal'; btn.disabled = false; }
                setTimeout(() => { if (btn) btn.innerHTML = arrowSVG + ' Unduh'; }, 2000);
            } else {
                if (btn) { btn.innerHTML = '✅ Terkirim'; btn.style.background = '#15803d'; }
                setTimeout(() => {
                    if (btn) { btn.innerHTML = arrowSVG + ' Unduh'; btn.style.background = ''; btn.disabled = false; }
                }, 3000);
            }
        });
    }

    function createBtn(url, extraStyle = '') {
        const btn = document.createElement('button');
        btn.className = 'omni-btn';
        btn.innerHTML = arrowSVG + ' Unduh';
        btn.title = 'Unduh dengan OmniFetch';
        if (extraStyle) btn.style.cssText = extraStyle;
        btn.onclick = (e) => { e.preventDefault(); e.stopPropagation(); sendToBackground(url, btn); };
        return btn;
    }

    function processNode(node) {
        if (!node || node.nodeType !== 1) return;
        if (processedNodes.has(node)) return;
        processedNodes.add(node);

        if (HOST.includes('youtube.com')) {
            if (node.matches('#top-level-buttons-computed') || node.matches('ytd-watch-metadata #actions')) {
                if (!node.querySelector('.omni-btn')) {
                    node.appendChild(createBtn(location.href));
                }
            }
        } else if (HOST.includes('instagram.com')) {
            if (node.tagName === 'ARTICLE') {
                const link = node.querySelector('a[href*="/p/"], a[href*="/reel/"]');
                const bar = node.querySelector('section, div[role="toolbar"]');
                if (link && bar && !bar.querySelector('.omni-btn')) {
                    const url = 'https://www.instagram.com' + link.getAttribute('href').split('?')[0];
                    bar.appendChild(createBtn(url, 'border-radius: 8px; padding: 5px 10px;'));
                }
            }
        } else if (HOST.includes('tiktok.com')) {
            if (node.matches('[class*="DivActionItemContainer"], [data-e2e="comment-icon"]')) {
                const parent = node.closest('[class*="DivActionItemGroup"]') || node.parentElement;
                if (parent && !parent.querySelector('.omni-btn')) {
                    const a = parent.closest('[class*="DivItemContainer"]')?.querySelector('a[href*="/@"]') || document.querySelector('a[href*="/@"]');
                    const url = a ? 'https://www.tiktok.com' + a.getAttribute('href').split('?')[0] : location.href;
                    parent.appendChild(createBtn(url, 'display: block; border-radius: 8px; margin: 8px auto 0; font-size: 11px;'));
                }
            }
        } else if (HOST.includes('twitter.com') || HOST.includes('x.com')) {
            if (node.tagName === 'ARTICLE' && node.getAttribute('data-testid') === 'tweet') {
                const timeEl = node.querySelector('time');
                const actionRow = node.querySelector('[role="group"]');
                if (timeEl && actionRow && !actionRow.querySelector('.omni-btn')) {
                    const link = timeEl.closest('a');
                    if (link) {
                        const url = 'https://twitter.com' + link.getAttribute('href');
                        actionRow.appendChild(createBtn(url, 'border-radius: 6px; padding: 5px 10px;'));
                    }
                }
            }
        }
    }

    // Process existing DOM
    document.querySelectorAll('*').forEach(processNode);

    // Observe using optimized technique
    let timeout;
    const observer = new MutationObserver((mutations) => {
        if (timeout) cancelAnimationFrame(timeout);
        timeout = requestAnimationFrame(() => {
            mutations.forEach(m => {
                if (m.addedNodes.length) {
                    m.addedNodes.forEach(node => {
                        if (node.nodeType === 1) {
                            processNode(node);
                            node.querySelectorAll('*').forEach(processNode);
                        }
                    });
                }
            });
        });
    });
    
    observer.observe(document.body, { childList: true, subtree: true });
})();
